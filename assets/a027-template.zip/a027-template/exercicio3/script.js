let contador = 0

const clicouXVezes = () => {
    contador++
    console.log(`Clicou ${contador} vezes`)
 }